package com.restarent.controller;

public class RestarentOpeningPage {
	
	
	

}
